// Exercise 3:
// Imagine you have an array of objects representing students with properties like name, age, and grade. Write a function that filters out students who are below a certain age and have a grade lower than a specified value.
// const representingStudents  = [
//     {
//         name : "Hayk",
//         age : 15,
//         grade : 8
//     },
//     {
//         name : "Narek",
//         age : 9,
//         grade : 4
//     },
//     {
//         name : "Arman",
//         age : 16,
//         grade : 9
//     },
//     {
//         name : "Areg",
//         age : 15,
//         grade : 8
//     },
//     {
//         name : "Manvel",
//         age : 14,
//         grade : 7
//     },
// ]


// function representingStudentsFilter(params) {
//     const filteredStudents = [];
//     representingStudents.forEach(student => {
//         if (student.age >= 13 && student.grade >= 5) {
//             filteredStudents.push(student)
//         }
//     })

//     console.log(filteredStudents);
//     return
// }
// representingStudentsFilter()

// Exercise 4:
// Create an array of objects representing products, each with properties like name, price, and category. Write a function that groups the products by category and calculates the average price for each category.


// const array = [
//     {
//         name : "Samsung",
//         price : 800,
//         category : "Phone"
//     },
//     {
//         name : "Samsung",
//         price : 800,
//         category : "Phone"
//     },
//     {
//         name : "Iphone",
//         price : 900,
//         category : "Phone"
//     },

//     {
//         name : "Dumblles",
//         price : 200,
//         category : "Fitness"
//     },
//     {
//         name : "horizontal bar",
//         price : 800,
//         category : "Fitness"
//     },
// ]
// function groups() {
//     const categoryForPhoneArray = [];
//     const categoryForFitnessArray = [];
//     let totalPriceForPhone = 0;
//     let totalPriceForFitness = 0;

//     array.forEach(element => {
//         if (element.category === "Phone") {
//             categoryForPhoneArray.push(element);
//             totalPriceForPhone += element.price;
//         } else if (element.category === "Fitness") {
//             categoryForFitnessArray.push(element);
//             totalPriceForFitness += element.price;
//         }
//     });

//     const averagePriceForPhone = totalPriceForPhone / categoryForPhoneArray.length;
//     const averagePriceForFitness = totalPriceForFitness / categoryForFitnessArray.length;

//     console.log("Phone Category:");
//     console.log(categoryForPhoneArray);
//     console.log("Average price: " + averagePriceForPhone);

//     console.log("Fitness Category:");
//     console.log(categoryForFitnessArray);
//     console.log("Average price: " + averagePriceForFitness);

//     return;
// }

// groups();
// Exercise 5:
// You have an array of temperature readings for a week. Write a function that calculates and returns the highest, lowest, and average temperature for the week.

// const array = [
//     {
//         address : "Armenia",
//         temperature : 36
//     },
//     {
//         address : "Canada",
//         temperature : 29
//     },

//     {
//         address : "America",
//         temperature : 35
//     },
//     {
//         address : "Dubai",
//         temperature : 45
//     },
// ]


// function calcTemp() {
//     array.sort((tempA, tempB) => tempA.temperature - tempB.temperature);

//     const highestTemp = array[array.length - 1].temperature;
//     const lowestTemp = array[0].temperature;

//     let totalTemperature = 0;
//     array.forEach(tempObj => {
//         totalTemperature += tempObj.temperature;
//     });
//     const averageTemp = totalTemperature / array.length;

//     console.log("The highest Temp: " + highestTemp);
//     console.log("The lowest Temp: " + lowestTemp);
//     console.log("The average Temp: " + averageTemp);
// }

// calcTemp();


// Exercise 6:
// Create an array of objects representing songs, each with properties like title, artist, and duration. Write a function that finds and returns the longest song.
// const array = [
//     {
//         title : "Halo",
//         artist : "Emma Heesters",
//         duration: 3.34
//     },

//     {
//         title : "They Dont Care About Us",
//         artist : "Michael Jackson",
//         duration: 4.41
//     },

//     {
//         title : "Halo",
//         artist : "Emma Heesters",
//         duration: 3.34
//     },

//     {
//         title : "Bow Down",
//         artist : "Enca ft. Noizy",
//         duration: 3.47
//     },
// ]


// function longestSong() {
//     array.sort((durationA, durationB) => durationA.duration - durationB.duration)
//     let longestSong = array[array.length - 1]
//     console.log("The Longest Song Is ", longestSong);
// }

// longestSong()



// Exercise 7:
// You have an array of tasks, each with properties like description, dueDate, and completed. Write a function that sorts the tasks by their due dates, and then by whether they are completed or not.


// const array = [
//     {
//         description: "Do 50 Push Ups",
//         dueDate: 2023,
//         completed: "Yes",
//     },
//     {
//         description: "Do 20 Pull Ups",
//         dueDate: 2026,
//         completed: "No",
//     },
//     {
//         description: "Do 50 ABS",
//         dueDate: 2024,
//         completed: "Yes",
//     },
// ]

// function toSortbyDueDates() {
//     const date = new Date()
    
//     array.sort((dueDateA, dueDateB) => dueDateA.dueDate - dueDateB.dueDate)

//     array.forEach(element => {
//         if(element.completed === "Yes"){
//             console.log("Task is Completed", element);
//         }
//     })
    
// }

// toSortbyDueDates()







// Exercise 8:
// Imagine you have an array of user objects, each with properties like username, email, and isActive. Write a function that returns an array of usernames of active users.

// const array = [
//     {
//         username: "Hayk_16",
//         email : "Hayk@gmail.com",
//         isActive : true
//     },
//     {
//         username: "Narek_22",
//         email : "Narek_22@gmail.com",
//         isActive : false
//     },
//     {
//         username: "Tigran_16",
//         email : "Tigran_16@gmail.com",
//         isActive : true
//     },
// ]


// function activeUsers() {
//     array.forEach(activeUser => {
//         if (activeUser.isActive === true) {
//             console.log(activeUser.username);
//         }
//     })
// }

// activeUsers()

// Exercise 9:
// Create an array of objects representing movies, each with properties like title, genre, and releaseYear. Write a function that filters the movies by genre and release year.

// const array = [
//     {
//         title: "Razlom San-Andreas",
//         genre: "drama",
//         releaseYear : 2015
//     },

//     {
//         title: "Transformers",
//         genre: "Fantastic",
//         releaseYear : 2015
//     },

//     {
//         title: "Iron Man",
//         genre: "drama",
//         releaseYear : 2008
//     },

//     {
//         title: "Transformers 2",
//         genre: "Fantastic",
//         releaseYear : 2020
//     },
// ]

// function FilterForFilms() {
//     const newArray = []
//     const newArray2 = []

//     array.filter(element => {
//         if (element.genre === "drama") {
//             newArray.push(element)
//         }
//         else if(element.genre === "Fantastic") {
//             newArray2.push(element)
//         }
//     })
//     console.log(newArray);
//     console.log(newArray2);
//     return
// }

// FilterForFilms()

// Exercise 10:
// You have an array of employee objects with properties like name, position, and salary. Write a function that calculates the total salary for all employees in a given position.

// const array = [
//     {
//         name: "Sargis",
//         position: "Manager",
//         salary: 300000
//     },
//     {
//         name: "Hayk",
//         position: "Junior Programmer",
//         salary: 150000
//     },
//     {
//         name: "Abraham",
//         position: "Team Lead",
//         salary: 3000000
//     },
//     {
//         name: "Manvel",
//         position: "Junior Programmer",
//         salary: 100000
//     },
// ]


// function toGroupPositions() {
//     const samePostions = []
//     let samePostionsSalary = 0

//     array.forEach(element => {
//         if (element.position === "Junior Programmer") {
//             samePostions.push(element)
//         }
//     })

//     samePostions.forEach(element => {
//         samePostionsSalary += element.salary
//     })

//     console.log(samePostions);
//     console.log("total salary is " + samePostionsSalary);
// }

// toGroupPositions()